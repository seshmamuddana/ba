import React from 'react'

const Hero = ({title, imageUrl}) => {
  return (
    <div className="hero container">
      <div className="banner">
        <h1>{title}</h1>
          <p>
          SM Health Care is a state-of-the-art facility dedicated to providing
          comprehensive medical services with compassion and expertise. Our 
          team of skilled professionals is committed to delivering personalized
          care tailored to each patient's needs. At SM Health Care, we prioritize
          your well-being, ensuring a seamless journey toward optimal health and wellness.
          </p>
      </div>
      <div className="banner">
        <img src={imageUrl} alt="hero" className="animated-image"/>
        <span>
          <img src="/Vector.png" alt="vector" />
        </span>
      </div>
    </div>
  )
}

export default Hero